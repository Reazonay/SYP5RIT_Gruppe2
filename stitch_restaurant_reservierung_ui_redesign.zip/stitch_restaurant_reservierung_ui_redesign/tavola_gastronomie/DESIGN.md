---
name: Tavola Gastronomie
colors:
  surface: '#fff8f5'
  surface-dim: '#e2d8d3'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fcf2ec'
  surface-container: '#f6ece7'
  surface-container-high: '#f0e6e1'
  surface-container-highest: '#ebe0db'
  on-surface: '#1f1b18'
  on-surface-variant: '#56423d'
  inverse-surface: '#352f2c'
  inverse-on-surface: '#f9efea'
  outline: '#89726c'
  outline-variant: '#ddc0b9'
  surface-tint: '#9e4127'
  primary: '#9b3f25'
  on-primary: '#ffffff'
  primary-container: '#bb563b'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb5a1'
  secondary: '#1b6d24'
  on-secondary: '#ffffff'
  secondary-container: '#a0f399'
  on-secondary-container: '#217128'
  tertiary: '#994128'
  on-tertiary: '#ffffff'
  tertiary-container: '#b8583d'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd1'
  primary-fixed-dim: '#ffb5a1'
  on-primary-fixed: '#3b0800'
  on-primary-fixed-variant: '#7f2a12'
  secondary-fixed: '#a3f69c'
  secondary-fixed-dim: '#88d982'
  on-secondary-fixed: '#002204'
  on-secondary-fixed-variant: '#005312'
  tertiary-fixed: '#ffdbd1'
  tertiary-fixed-dim: '#ffb5a0'
  on-tertiary-fixed: '#3b0900'
  on-tertiary-fixed-variant: '#7d2c15'
  background: '#fff8f5'
  on-background: '#1f1b18'
  surface-variant: '#ebe0db'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

Das Designsystem verbindet die einladende Gastlichkeit traditioneller Gastronomie mit der kompromisslosen Funktionalität moderner Service-Software. Es bedient zwei Kernzielgruppen: Gäste, die schnell und genussorientiert einen Tisch reservieren möchten, sowie Gastronomie-Personal, das während der Stoßzeiten verlässliche, fehlerresistente Arbeitsabläufe benötigt.

### Tonalität und Ästhetik
- **Warm & Geerdet:** Reduzierte, natürliche Wärme durch Terrakotta-, Creme- und Salbeitöne, inspiriert von natürlicher Tischkultur, Keramik und Leinen.
- **Taktil & Sachlich:** Verzicht auf illustrative Spielereien, Verläufe und neumorphe Schatten. Die visuelle Sprache setzt auf ruhigen Weißraum, klare 1px-Konturen und strukturierte Oberflächen.
- **Barrierearm & Funktional:** Volle Konformität nach WCAG AA (mindestens 4.5:1 für Normaltext, 3:1 für grafische Bedienelemente). Keine Zustandsvermittlung ausschließlich über Farbe; jeder Status wird zusätzlich textlich oder ikonografisch transportiert.
- **Lokalisierung:** Konsequente Verwendung mitteleuropäischer Konventionen (deutsche Fachtermini, Währungsformat `24,50 €`, Datumsformat `TT.MM.JJJJ`, 24-Stunden-Zeitraster `19:30 Uhr`).

## Colors

Das Farbmodell ist rein additiv auf Barrierefreiheit, Lesbarkeit und Wärme ausgerichtet. Die Farbpalette operiert ausschließlich im Hellmodus, um auch bei variierenden Lichtverhältnissen im Lokal (z. B. Sonnenlicht im Gastgarten oder schwaches Servicelicht) höchste Erkennbarkeit zu garantieren.

### Farbpalette und Verwendung
- **Primärton (Terrakotta - `#C05A3E`):** Hauptaktionsfarbe für interaktive Schlüsselelemente, Buchungsbestätigungen und primäre Buttons.
  - Hover / Pressed: `#A84C32` (mind. 3:1 Kontrast gegen Standard)
  - Subtle / Container: `#F9EFEA` (für Selektionshintergründe, Badges, aktive Kalendertage)
- **Sekundärton (Kräutergrün - `#2E7D32`):** Reservierungsstatus „Bestätigt“, freie Kapazitäten und positive Rückmeldungen.
  - Subtle / Status-Fläche: `#E8F5E9`
- **Neutralfarben (Schiefer & Warmgrau):**
  - Primärtext: `#2B2623` (Kontrastverhältnis > 11:1 auf Weiß und Creme)
  - Sekundärtext: `#6E6761` (WCAG AA-konform für erklärenden Fließtext und Metadaten)
  - Rahmen & Divider: `#E5E0D8` (subtile Abgrenzung)
  - Inhaltsrahmen: `#E6E0D6` (Kantenführung für Cards und Tabellenzeilen)
- **Hintergrundtöne:**
  - Basisfläche (Canvas): `#FBF9F5` (Warmes Alabaster-Creme)
  - Sektions- und App-Bar-Alternativen: `#F5F1EA`
  - Oberflächen / Karten: `#FFFFFF` (Reines Weiß für höchsten Lese- und Touchkontrast)

## Typography

Die Typografie basiert auf einer Kombination aus **Plus Jakarta Sans** für Headlines und Fließtexte sowie **Inter** für Interaktionsbeschriftungen, Formular-Labels, Tabellen und Ziffern.

### Richtlinien
- **Keine Zierelemente:** Schnörkelige Display-Schriften sind ausdrücklich untersagt. Die Seriosität und Lesbarkeit bei Schichtübergaben und schnellen Reservierungsabfragen stehen im Fokus.
- **Formular-Labels:** Formularbeschriftungen verwenden `label-md` in `#2B2623` und stehen stets permanent oberhalb des Feldes. Platzhaltertext wird niemals als Ersatz für Labels verwendet.
- **Numerische Lesbarkeit:** Für Zeitangaben, Tischnummern, Personenanzahl und Rechnungsbeträge wird stets tabellarische Ziffernausrichtung (`font-variant-numeric: tabular-nums`) aktiviert.

## Layout & Spacing

Das Layout folgt einem fluiden Rastersystem, das sich dynamisch an Smartphones, Servicetablets im Kassenbereich und Desktop-Monitore im Reservierungsbüro anpasst.

### Breakpoints & Spaltenraster
- **Mobile (< 768px):** 4 Spalten, 16px Außenabstand (`margin`), 16px Zwischenspalten (`gutter`). Vertikale Stapelung aller Formularfelder.
- **Tablet (768px – 1024px):** 8 Spalten, 24px Außenabstand (`margin-tablet`), 16px Zwischenspalten (`gutter`). Split-View für Tischauswahl links und Reservierungsdetails rechts.
- **Desktop (> 1024px):** 12 Spalten, max. Inhaltsbreite 1280px zentriert, 40px Außenabstand (`margin-desktop`), 24px Zwischenspalten (`gutter-desktop`).

### Rhythmus & Touch-Ziele
- Alle interaktiven Komponenten besitzen eine Mindesthöhe bzw. Mindestklickfläche von **44px** (auf Handhelds und Tablets für das Servicepersonal empfohlen: 48px).
- Abstände innerhalb von Komponenten nutzen die strikte Skala von `space-xs` (4px) bis `space-xl` (32px).

## Elevation & Depth

Das Designsystem verzichtet vollständig auf diffuse Schlagschatten, künstliche 3D-Effekte oder Blur-Filter. Tiefenwirkung entsteht exklusiv durch Tonalität und feine Konturen.

### Hierarchie-Ebenen
- **Ebene 0 (Canvas):** Grundfläche in `#FBF9F5` bzw. `#F5F1EA`.
- **Ebene 1 (Karten, Listenblöcke, Formulare):** Reines Weiß (`#FFFFFF`), begrenzt durch eine 1px starke Konturlinie in `#E6E0D6`. Kein Schatten.
- **Ebene 2 (Aktive Selektion, Hover, Dropdowns):** Weiß (`#FFFFFF`) mit primärer Kontur `#C05A3E` (1.5px) oder dezenter Begleitkontur `#2B2623` bei Menüs. Zur visuellen Trennung schwebender Modals über dem Canvas wird ausschließlich ein 1px Rand mit einer dezenten, warm abgetönten Abblende (`#2B2623` mit 20% Deckkraft) verwendet.

## Shapes

Die Formensprache verwendet ruhige, funktionale Radien zwischen 6px und 10px. Dies verleiht der Benutzeroberfläche eine haptische, zugängliche Anmutung, ohne verspielt zu wirken.

- **Standard-Elemente (Inputs, Buttons, Tabellenzeilen, Badges):** 8px Eckradius (`roundedness: 2`).
- **Cards und Panels:** 10px bis maximal 16px Radius (`rounded-lg` bis `rounded-xl`).
- **Keine Pill-Shapes:** Tasten und Eingabefelder behalten klare Rechteckgeometrien mit abgerundeten Ecken, um die Klickbarkeit als handfestes UI-Element zu betonen.
- **Rahmenstärke:** Grundsätzlich 1px solid. Fokus- und Auswahlrahmen betragen 2px solid im Terrakotta-Farbton `#C05A3E`.

## Components

### 1. Buttons
- **Primär:** Hintergrund `#C05A3E`, Text `#FFFFFF`, Mindesthöhe 44px, Radius 8px, Innenabstand horizontal 20px. Hover: `#A84C32`. Fokus: 2px Outline in `#C05A3E` mit 2px Versatz (Offset).
- **Sekundär (Outline):** Hintergrund transparent / `#FFFFFF`, Rand 1px solid `#E5E0D8`, Text `#2B2623`. Hover: Hintergrund `#F5F1EA`, Rand `#6E6761`.
- **Tertiär (Ghost):** Hintergrund transparent, Text `#C05A3E`. Für sekundäre Abbruchaktionen oder reine Tabellennavigation.

### 2. Eingabefelder & Formulare
- **Aufbau:** Immer vertikaler Stapel aus sichtbarem Label (`label-md`, `#2B2623`), Eingabefeld (44px Höhe, weißer Hintergrund `#FFFFFF`, 1px Rand `#E5E0D8`, Radius 8px) und optionalem Hilfetext (`body-sm`, `#6E6761`).
- **Fokus-Zustand:** Rand wechselt auf 2px solid `#C05A3E`.
- **Fehlerzustand:** Rand 2px solid `#B00020`, Fehlermeldung unterhalb mit vorangestelltem Warn-Icon und Text in `#B00020`.

### 3. Reservierungs- & Status-Chips
- **Kräutergrün (Bestätigt / Frei):** Hintergrund `#E8F5E9`, Rand 1px solid `#A5D6A7`, Text `#1B5E20`. Icon: Häkchen oder gefüllter Punkt.
- **Terrakotta (In Prüfung / Warteliste):** Hintergrund `#F9EFEA`, Rand 1px solid `#F0CEBE`, Text `#A84C32`. Icon: Sanduhr / Uhrzeitsymbol.
- **Neutral (Storniert / Beendet):** Hintergrund `#F5F1EA`, Rand 1px solid `#E5E0D8`, Text `#6E6761`. Icon: Durchgestrichener Kreis.
- *Regel:* Kein Status-Chip darf seine Bedeutung allein über die Farbe vermitteln.

### 4. Cards & Tischübersicht
- Weißer Hintergrund `#FFFFFF`, 1px Border `#E6E0D6`, 8px Innenradius, Polsterung 16px bis 24px.
- Trennung von Tischinformationen (z. B. „Tisch 14 – 4 Pers.“) über feine horizontale Divider (`#E5E0D8`).

### 5. Checkboxen & Radio-Buttons
- Mindestabmessung 20x20px mit mindestens 44x44px Trefferfläche.
- Inaktiver Rand 1.5px solid `#6E6761`.
- Aktiver Zustand: Füllung `#C05A3E` mit weißem Kontrollzeichen.
- Begleittext links- oder rechtsbündig immer klickbar mit dem Label verknüpft.

### 6. Gastronomiespezifische Komponenten
- **Schichtplan- / Zeitleisten-Slot:** Touch-freundliche Zeitblöcke (z. B. `18:00`, `18:30`) mit 44px Mindesthöhe, klarer Kennzeichnung belegter Zeiten (Schraffur + Label „Belegt“) und freier Zeiten (weiße Karte, Terrakotta-Rand bei Selektion).
- **Gäste-Notizblock:** Spezifisches Infofeld mit Allergie- und Sonderwünsche-Badges (z. B. „Glutenfrei“, „Hochstuhl“), optisch hervorgehoben in `#F9EFEA` mit 1px `#C05A3E` Kontur.